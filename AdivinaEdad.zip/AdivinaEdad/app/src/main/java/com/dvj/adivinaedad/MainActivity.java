package com.dvj.adivinaedad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.w3c.dom.Text;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    String nombre;
    TextView edadTexto;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creo que el error da porque no he conseguido coger el nombre
        EditText editText = this.findViewById(R.id.nombre);
        nombre = editText.getText().toString();

        edadTexto = this.findViewById(R.id.etiquetaEdad);

    }


    public void consultarEdad(View view) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.agify.io/")
                .addConverterFactory(GsonConverterFactory.create(
                        new GsonBuilder().serializeNulls().create()
                ))
                .build();
        EdadAPIService edadAPIService = retrofit.create(EdadAPIService.class);
        Call<EdadEstimada> call =  edadAPIService.getEdad(nombre);

        call.enqueue(new Callback<EdadEstimada>(){

            @Override
            public void onResponse(Call<EdadEstimada> call, Response<EdadEstimada> response) {

                if(response.isSuccessful()){
                    int edad  = response.body().getAge();
                    edadTexto.setText(edad);
                } else {
                    Log.d("Error", "Ha habido un error");
                    return;
                }
            }

            @Override
            public void onFailure(Call<EdadEstimada> call, Throwable t) {
                Log.d("Error", t.toString());
            }
        });
    }


}